import copy
import json
import pathlib
import unittest

from owner_type_compatibility import errors

ROOT = pathlib.Path(__file__).resolve().parent
ORIGINAL = ROOT / "original-payloads"


class OwnerTypeCompatibilityTests(unittest.TestCase):
    def body(self, path):
        return json.loads(path.read_text())

    def test_original_personal_repository_bodies_are_rejected(self):
        for name in ("window-main-protection.json", "closure-main-protection.json"):
            with self.subTest(name=name):
                self.assertTrue(errors("User", self.body(ORIGINAL / name)))

    def test_revised_personal_repository_bodies_pass(self):
        for name in ("window-main-protection.json", "closure-main-protection.json"):
            with self.subTest(name=name):
                self.assertEqual(errors("User", self.body(ROOT / "payloads" / name)), [])

    def test_null_personal_push_restrictions_are_supported(self):
        self.assertEqual(errors("User", {"restrictions": None}), [])

    def test_empty_personal_push_restriction_object_is_rejected(self):
        self.assertTrue(errors("User", {"restrictions": {"users": [], "teams": [], "apps": []}}))

    def test_empty_personal_bypass_object_is_rejected(self):
        self.assertTrue(errors("User", {"required_pull_request_reviews": {"bypass_pull_request_allowances": {}}}))

    def test_empty_personal_dismissal_object_is_rejected(self):
        self.assertTrue(errors("User", {"required_pull_request_reviews": {"dismissal_restrictions": {}}}))

    def test_nonempty_personal_bypass_and_dismissal_are_rejected(self):
        for field in ("bypass_pull_request_allowances", "dismissal_restrictions"):
            with self.subTest(field=field):
                self.assertTrue(errors("User", {"required_pull_request_reviews": {field: {"users": ["example"]}}}))

    def test_organization_type_does_not_trigger_personal_constraint(self):
        for name in ("window-main-protection.json", "closure-main-protection.json"):
            with self.subTest(name=name):
                self.assertEqual(errors("Organization", self.body(ORIGINAL / name)), [])

    def test_unknown_owner_type_fails_closed(self):
        for owner_type in (None, "", "user", "Enterprise", "Bot"):
            with self.subTest(owner_type=owner_type):
                self.assertTrue(errors(owner_type, {"restrictions": None}))

    def test_revised_policy_intent_is_preserved(self):
        for name, count in (("window-main-protection.json", 0), ("closure-main-protection.json", 2)):
            with self.subTest(name=name):
                previous = self.body(ORIGINAL / name)
                current = self.body(ROOT / "payloads" / name)
                expected = copy.deepcopy(previous)
                del expected["required_pull_request_reviews"]["bypass_pull_request_allowances"]
                self.assertEqual(current, expected)
                self.assertIs(current["enforce_admins"], True)
                self.assertIs(current["required_conversation_resolution"], True)
                self.assertIsInstance(current["required_pull_request_reviews"], dict)
                self.assertEqual(current["required_pull_request_reviews"]["required_approving_review_count"], count)


if __name__ == "__main__":
    unittest.main(verbosity=2)
