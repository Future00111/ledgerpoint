"""Offline owner-type checks. This module performs no network or live writes.

Passing these checks does not establish GitHub server acceptance or installed
policy. The rejected original G4 bodies are retained as regression fixtures.
"""

import argparse
import json
import pathlib
import sys


def errors(owner_type, body):
    issues = []
    if owner_type not in {"User", "Organization"}:
        return ["Unknown repository owner type; stop for a fresh owner readback."]
    if not isinstance(body, dict):
        return ["Protection body must be a JSON object."]
    if owner_type == "User":
        if body.get("restrictions") is not None:
            issues.append("Personal repository: non-null push restrictions are organization-only.")
        reviews = body.get("required_pull_request_reviews")
        if isinstance(reviews, dict):
            for field in ("dismissal_restrictions", "bypass_pull_request_allowances"):
                if field in reviews:
                    issues.append("Personal repository: omit " + field + "; empty actor objects still declare restriction fields.")
    return issues


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--owner-type", required=True)
    parser.add_argument("payload", nargs="+", type=pathlib.Path)
    args = parser.parse_args()
    reports = [{"file": str(p), "errors": errors(args.owner_type, json.loads(p.read_text()))}
        for p in args.payload]
    print(json.dumps({"scope": "OFFLINE_OWNER_TYPE_CHECK_ONLY", "results": reports}, indent=2))
    return int(any(r["errors"] for r in reports))


if __name__ == "__main__":
    sys.exit(main())
