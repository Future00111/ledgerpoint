C7 G4 personal-repository correction — review only

Two revised protection bodies omit the empty bypass allowance object that is the likely cause of the reported HTTP 422. The original bodies are retained as negative regression fixtures. No other protection field changes. The window still requires a PR with zero approving reviews; closure still requires two reviews. Administrator enforcement remains true.

10 offline tests pass. These are owner-type compatibility and preservation checks, not GitHub server acceptance. The revised bodies have not been applied or retried. GitHub acceptance and native PR enforcement must be read back after a newly authorized call; failures stop the process.

The repository merge-method PATCH already succeeded and must not be replayed. The remaining action proposal is one specifically authorized protection PUT. Changed closure bytes also require renewed approval. G5–G7 remain pending.

Review actions-and-verification.json and correction-review.json before approving anything. Native GraphQL must prove zero bypass allowances; an omitted REST property is insufficient. Existing UI verification requirements remain unless explicitly revised. Environment admin bypass remains available but its use is forbidden. Closure to two reviews blocks future owner-authored PRs until two eligible reviewers are available.

The original raw HTTP failure ZIP was not supplied. This package verifies current live state and original approved payloads, while identifying the precise cause as an inference. It makes no raw-failure-receipt or unpublished-commit attestation.

Run the offline regression checks:
  python3 test_owner_type_compatibility.py
Validate proposed bodies:
  python3 owner_type_compatibility.py --owner-type User payloads/window-main-protection.json payloads/closure-main-protection.json
