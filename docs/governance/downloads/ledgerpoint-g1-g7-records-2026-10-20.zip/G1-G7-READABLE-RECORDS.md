# LedgerPoint — G1 to G7 main records

# LedgerPoint G1–G7 records
Packaged 2026-10-20 at the owner's request.

Start with G1-G7-READABLE-RECORDS.md for the main documents in gate order.
The docs/ folder contains the complete selected C7 gate records and related
approval/proposal/evidence files, preserved byte for byte.
MANIFEST.json records every original file's size and SHA-256.

Latest decision: G7 ACCEPTED for run 38621069723, attempt 1, G
706dc6a31f85733ba0c251f40b2c09f5a9312269 and C7
787d76decfa345e3c1104231e08d5ab00bc90259.
The owner-acceptance record is authoritative for that G7 decision.
Older PENDING text describes historical stages and is retained as evidence.
The G7 acceptance covers disposable-CI qualification, not production release.
Any separate control-restoration/closure conditions retain their own scope.

Included: approvals and preparation/application/merge/dispatch reports,
source-bound verification, six accounting results, concurrency/journal-lock
evidence, 18 negative controls, five cleanup attestations, original G7 artifact
and logs, integrity manifests, and the recorded owner acceptance.
This package is a snapshot; it does not rerun tests or change live controls.


---

# G1 — development review exception approval

Source: `docs/governance/ledgerly-tr01-c7-single-owner-g1-approval.md`

# Exact C7 single-owner exception — G1-only owner approval

**Decision date:** 2026-10-13.

**Status:** G1 APPROVED — GOVERNANCE EXCEPTION ONLY.

**G2–G7:** PENDING; no designation or execution authority.

## Decision source and revision verification

Recorded from the owner's direct instruction in this workspace conversation
(`lee449`), not from an AI recommendation or inferred consent:

> I approve G1 only for proposal commit 4f5e87d6bfb6c3a468c947903a23d3beedf7a676, including its five stated review substitutions, risks and single-use limits. Verify the exact revision and record my approval.
> G2–G7 remain pending. Do not designate C7, change controls, merge, run qualification, deploy or enter Phase A.

Verified the existing exact Git object and proposal bytes:

- Proposal commit: `4f5e87d6bfb6c3a468c947903a23d3beedf7a676`.
- Proposal commit tree: `b810843e4f71e0290ec4c169cf4c266c468bb5c5`.
- Proposal file:
  `docs/governance/drafts/ledgerly-tr01-c7-single-owner-designation-activation-exception-proposal.md`.
- Proposal Git blob: `f6b2b71c05d1b1992581d72965a394d829fae6b0`.
- Proposal file SHA-256:
  `ca8857b94eb5894c385805d372832d8df7cc364c88216eadb4683ea108ebf186`.
- Checked-out proposal bytes match that exact committed revision and hash.
  The intervening local asset-metadata commit is preserved; it does not alter
  the proposal or expand the approved revision.

This is a record of the actual owner instruction, not a cryptographic signature
or independent-human review. The proposal names the repository owner account
`Future00111`; no new independent GitHub-account attestation or Environment
release is claimed here. Actual GitHub actors must be verified before any
separately authorized future action.

## Approved G1 scope

The owner approves the proposal's governance replacements for this exact
development-only scope, accepts the stated separation-of-duties and other
risks, and accepts its single-use limits. The five replacements are:

1. Fresh independent exact-C7 implementation/security review feeding final
   designation: a later explicit owner source/evidence decision instead.
2. Two fresh approvals of exact A against exact B: a later exact A/B owner
   decision and separately authorized ordinary PR merge instead.
3. An Environment approver distinct from the initiator/self-review prevention:
   a later normal owner Environment release for the specific development job.
4. A distinct second-human pre-dispatch review: a later fresh owner attestation.
5. Independent activated-result review: a later separate owner verification
   and development-result acceptance.

These are approved governance substitutions, **not completed reviews,
designation, merge approval, run approval or independent-human assurance**.
Every retained technical safeguard, stop condition, scope exclusion and expiry
clause of the exact proposal remains required.

The bounded implementation is C7
`787d76decfa345e3c1104231e08d5ab00bc90259`. This identifies the exception's
scope only; **C7 is not designated authoritative by this record**.
The limits are one separately authorized activation merge and at most one
separately authorized activated development dispatch. A failed run consumes
that dispatch authority; no automatic retry or successor substitution.
No merge/run allowance is exercised or granted at action time by G1 alone.

## Gate readback

| Gate | Status after this instruction |
| --- | --- |
| G1 — Governance exception | APPROVED for the exact proposal revision above |
| G2 — Final designation | PENDING; no C7 designation |
| G3 — Activation preparation | PENDING; no A prepared or authorized here |
| G4 — Configuration | PENDING; no controls/pins/admission/reviewer changes |
| G5 — Exact A/B acceptance and merge | PENDING; no merge approval or merge |
| G6 — Activated development dispatch and normal owner release | PENDING; no dispatch/run/Environment release |
| G7 — Result acceptance and closure | PENDING; no activated result accepted |

Future actions require their own exact values, preflight evidence and explicit
authorization as specified by the approved G1 proposal. G1 does not silently
approve later configuration, waive failed technical checks or make unknown A/G
identities approved. Main, frozen candidates and live controls are unchanged
by this documentation action. No remote push, migration, qualification,
production/Helium access, deployment or Phase A was performed or authorized.

The proposal is preserved unchanged as the reviewed revision. This separate
record supplies its effective G1 approval without rewriting the proposal,
historical reviews or prior approval records.


---

# G2 — C7 development designation

Source: `docs/governance/ledgerly-tr01-c7-development-designation-approval.md`

# Exact C7 — G2 development-only identity designation

**Decision date:** 2026-10-13.
**Status:** OWNER-APPROVED G2 — DEVELOPMENT ONLY.

## Actual owner decision

Recorded from the owner's direct workspace instruction (`lee449`):

> G2: After rechecking the G1 record and verified acceptance evidence, I approve exact C7 787d76decfa345e3c1104231e08d5ab00bc90259 as the NEW AUTHORITATIVE IMPLEMENTATION IDENTITY for development only. Accept its recorded source/tree/parent, reconciled evidence, qualification run 38284785813 attempt 1, 18 negative controls and five cleanup results.

Exact C7 is designated:

**NEW AUTHORITATIVE IMPLEMENTATION IDENTITY**

**Scope: development only, under the approved single-owner G1 exception.**
This owner decision is not an independent-human review or production release.

- Commit: `787d76decfa345e3c1104231e08d5ab00bc90259`.
- Tree: `aa0360267a0d1987626ae9650238d66f04f667b9`.
- Sole parent: `c795945c4a5d4815804a86b9d5f2bdc77573d38f`.
- G1 proposal: `4f5e87d6bfb6c3a468c947903a23d3beedf7a676`;
  proposal SHA-256 `ca8857b94eb5894c385805d372832d8df7cc364c88216eadb4683ea108ebf186`.
- G1 approval source:
  `docs/governance/ledgerly-tr01-c7-single-owner-g1-approval.md`, backed up
  at `68180fa598a5042df8111ea6c30e142d49176c86`.
- Qualification: existing GitHub run `38284785813`, attempt 1, success at
  exact C7; no new run performed.
- Accepted artifact ZIP SHA-256:
  `a21a4f0de4938876e5b17457d91a16f177d037af4e5ffcbb258194ccb60f83de`.
- Evidence SHA-256:
  `bd6df83ad8c0512db825b7afbc0cb29314c9e04ce1fc13bfe10e368d69a3332b`.
- Schema SHA-256:
  `6ba3d5f595f81e81db238b843c16b667e775384952855482ce9a978775d6ca0f`.
- Reconciled original/fresh log ZIPs:
  `bbf0b248bde5938492a5189fd1d12d9383ab11866a2835262c38d5812c557f06` /
  `f61c2abb73f30412af4918ab82f36c2f3a7abc804c6ebe6a0d0b344db5656b52`.

Before recording designation, rechecked the exact G1 proposal/approval, C7
tree/parent, authenticated existing run source/attempt/success, original
artifact integrity and evidence/schema bytes, strict schema-v2 validation,
all 18 true negative controls and all five true cleanup flags. The retained
log reconciliation receipts and archive hashes agree. Prior exact-source,
concurrency, privilege and isolation review receipts remain retained.

## Separate G3 instruction and unchanged pending gates

The owner separately instructed:

> G3: Prepare the constrained activation head from exact main base 0da401737f35d68b9404982baad7405fe997636a. Require C7 and that base as ancestors, obey the ten-path inventory, validate the result and return exact identities and a draft PR. Stop if main has advanced.
> G4–G7 remain pending: no live control changes, merge, qualification run, migration, deployment or Phase A.

G3 authorizes review-branch preparation/publication of a draft PR only, including
the local merge ancestry necessary to prepare A. It does not authorize merging
the PR into main. Preparation evidence will be recorded separately outside A.
If live main differs from the named B, stop preparation/publication.

G1 and G2 are approved; G3 preparation is authorized, not exact-A acceptance.
G4 configuration, G5 exact-A/B approval and protected-main merge, G6 dispatch/
normal owner release, and G7 activated-result acceptance remain **PENDING**.
No live control/pin/admission/reviewer change, protected-main merge, new
qualification, migration, deployment, production/Helium access or Phase A is
authorized by this record. Frozen C through C7 and historical evidence remain
unchanged. Existing candidate qualification applies only to exact C7, not A/G.


---

# G3 — activation preparation

Source: `docs/governance/drafts/ledgerly-tr01-c7-activation-preparation-report.md`

# Exact C7 development designation and G3 activation preparation

**2026-10-13 — G1/G2 owner-approved; G3 preparation complete. G4–G7 PENDING.**
AI preparation/verification, not independent-human review or A/B acceptance.

## Backup and owner designation

Normally backed up `proposal-local/tr01-c7-single-owner-exception`; Git remote
and authenticated GitHub readback confirm exact
`68180fa598a5042df8111ea6c30e142d49176c86`.
No force push, other-ref push or main/frozen update was used.

G2 is recorded in
`docs/governance/ledgerly-tr01-c7-development-designation-approval.md`,
local record commit `c18f2e10a3606b5d5624372973ba3845dc0d00fa`.
The owner designates exact C7 as the **NEW AUTHORITATIVE IMPLEMENTATION
IDENTITY**, **development only** under the approved G1 exception.
Rechecked G1 exact revision/approval, C7 tree/parent, existing run/attempt/
success, artifact/evidence/schema bytes and strict schema-v2 acceptance,
18 negative controls, five cleanup flags and reconciled log archive hashes.
No new qualification or database work occurred.

## Exact activation preparation identities

- Draft PR: https://github.com/Future00111/ledgerpoint/pull/26
- Ordinary review branch: `activation/tr01-c7-development`.
- A / verified remote head: `ead19106aaad76d604e8595337b5ab2fddda68d0`.
- A tree: `bf7c91fac7fe09d8458a327dd79464ea1a3973ad`.
- A first parent / exact reviewed B:
  `0da401737f35d68b9404982baad7405fe997636a`.
- A second parent / exact C7:
  `787d76decfa345e3c1104231e08d5ab00bc90259`.
- C7 tree: `aa0360267a0d1987626ae9650238d66f04f667b9`;
  sole parent `c795945c4a5d4815804a86b9d5f2bdc77573d38f`.
- A workflow SHA-256:
  `ad06da35f4269fbbf46e1fd4ccabf6082d309963e39b577e17ac948c546afc20`.
- C7 564-file execution-domain SHA-256:
  `fcd81d162cbfc406853bdd13c853cd49f81fd814622a7f90116724e668eb82d1`.

A was prepared in a separate worktree as a normal local merge of C7 from B.
The deliberate merge resolution restores B everywhere outside the approved
inventory; it does not import the divergent C7/integration runtime tree.
This local ancestry preparation is not the separately gated protected-main
merge G. **No G exists from this preparation.**

Exactly the ten allowed paths differ: the canonical workflow plus the nine
governance documents listed in the activation proposal. All other Git blobs,
modes and path absences equal B. The nine documents were absent from B and
retain the workspace historical baselines with explicit bounded G1/G2/G3
addenda; historical reviews are not asserted to be fresh human approvals.
No TypeScript, application/runtime, SQL, schema, package or lockfile changed.
Workflow equals the reviewed prototype except for its terminating LF.

## Preparation validation results

| Check | Result and limits |
| --- | --- |
| Full tree/inventory and parent/ancestry comparison | PASS; B and C7 are ancestors; exactly ten changed paths; all other B entries/absences identical |
| YAML parse and safety assertions | PASS; unique keys, manual/protected-main guards, pinned actions, separate exact checkouts, no persisted credentials, frozen install, activated invocation and candidate-only always-run upload |
| Actual isolated host installation | PASS; pnpm 10.26.1, frozen lockfile, ignore scripts, root workspace filter; no tracked source changes |
| Actual C7 module dependency resolution | PASS; without candidate node_modules, module resolves AJV 8.20.0 from A host install and imports without running qualification |
| Actual A/C7 source-context fixture | PASS; positive context, nine non-workflow digests equal qualified C7, correct A workflow digest; five negative source/ref/ancestry cases rejected |
| C7 external binding regression | PASS; no database work |
| C7 schema convergence regression | PASS; mocked calls, no schema push |
| C7 identity/acceptance suite | PASS; fixtures test acceptance/rejection and source separation, not actual GitHub authorization |
| B-exact producer contract | 28 cases passed, plus the previously optional actual-C7 case passed in a targeted run; 29 covered, no failures |
| C7 offline policy suite | Static policy case passed; six image-dependent cases skipped because no image was supplied; no image build/container test claimed |

Host validation ran locally on NixOS with Node 24.13.0, not hosted Ubuntu
24.04. Corepack shims/cache used an isolated writable directory rather than
changing the immutable/global Nix toolchain. The exact pinned prepare/install
steps and candidate AJV fallback were executed there.

The minimal host installation intentionally lacks API `pg`. For the broader
acceptance harness, existing API dependencies were linked only after verifying
the API manifest and lockfile byte-exact against C7. This test-only link was
not added to A or required by the prepared hosted workflow. The producer test
belongs to B/A, not C7; it was run from its proper source.

Preserved initial review-harness setup failures: absent API dependency, wrong
producer-test source and local Git index-scrutiny permission. Corrected only
the harness dependency/source/command-local index permission, not frozen code
or GitHub controls. Those are not failed qualification runs.
The local context fixture simulates CI metadata and reports itself explicitly
as not qualification evidence. No synthetic passing TI-03 artifact was emitted.

## Evidence retention and remaining gates

Per-file Git blob/mode/SHA-256, identities and check receipts:
`ledgerly-tr01-c7-activation-preparation/validation.json`.
Full B/A patch, host install and fixture/unit logs:
`generated-artifacts/ledgerly-pr25-ai-review/g3-*` and the copied host logs there.
Historical failure logs remain retained, not silently replaced.

Fresh main=B readbacks were required before preparation, publication and draft
PR creation. Draft PR readback confirms exact A/B and draft/open state.
Main, all frozen refs, Environment, rulesets and main protection compare
unchanged across publication. Local workspace runtime/history is preserved;
the review worktree is separate, A is pinned by its local and remote branch.

G4 must separately approve exact live configuration/restoration values and
verify effective readback. G5 must accept exact A/B and reviewed merge tree
before any ordinary main merge, rechecking main=B. G6 must separately
authorize one exact-G activated development dispatch and normal owner release
after all preflights. G7 must accept the new result/cleanup separately.
The owner exception and development designation do not approve these actions.

The existing candidate qualification remains exact-C7 only. This report is
not activated qualification, production assurance or Phase A permission.
No controls/pins/admission/reviewer changes, protected-main merge, qualification
dispatch, migration, production/Helium access or deployment occurred.


---

# G4 — corrected configuration and verification

Source: `docs/governance/drafts/ledgerly-tr01-c7-g4-corrected-application-report.md`

# Corrected G4 application — API success, authenticated UI pending

**Latest outcome:** one exact corrected main-protection PUT returned HTTP 200.
Independent REST/native readbacks and all 22 preservation/enforcement checks
passed. **G4 UI verification remains pending for Codex; G5–G7 remain pending.**
No actual authenticated browser inspection is claimed.

This execution follows the owner relay recorded in
`../ledgerly-tr01-c7-g4-corrected-configuration-approval.md`; it is owner
authorization, not independent-human review. Original approvals, the original
HTTP 422 request/failure and prior review documents remain unchanged.

## Exact authority and action

- Approved revised review ZIP SHA-256:
  `090b51fd4ad655001db0fa4b725610c1af2b9b326431b446d67e7999c71a79d7`.
- Applied corrected window body SHA-256:
  `d96d829a3df69c397b032fe1a1eb308d9f98fada72efcb8495a9e17c18b354e6`.
- Approved future closure body SHA-256:
  `fc4d8f277df504e9fff50a2e9bb30a52d4fe22fd25cff3013d78a4bfb9724e7c`.
- Owner relay text SHA-256:
  `3d9c43062ffd8828e865898d961e5210719f77c68799bfe35038bc3170358176`.

ZIP CRC and all 35 revised-package manifest hashes verified. Both exact payload
hashes verified before preflight and the window hash again at action time.
The reviewed read-only preflight was run into a separate receipt directory,
without modifying historical evidence.

One `PUT /repos/Future00111/ledgerpoint/branches/main/protection`,
API version `2022-11-28`, using the exact 509-byte corrected window body.
No body edits, PATCH replay, retry, permission expansion or closure.
The consumed-attempt marker prevents rerunning the execution script.

## Fresh preflight and observation times

All 20 preflight checks passed, using the existing authenticated GitHub CLI
owner `Future00111`, ID 318002590, user-owned repository.
Observation window 2026-10-13 **17:26:09–17:26:16 UTC**.
Immediate main-ref, PR A/B/state and main-protection guards also passed.

- PR #26 remained OPEN/draft with A
  `ead19106aaad76d604e8595337b5ab2fddda68d0`.
- B/main remained `0da401737f35d68b9404982baad7405fe997636a`.
- C7 remained `787d76decfa345e3c1104231e08d5ab00bc90259`.
- A tree remained `bf7c91fac7fe09d8458a327dd79464ea1a3973ad`;
  ordered parents B then C7.
- Main protection matched the reviewed pre-state; native main rule had zero
  bypass allowances with complete pagination.
- Merge-only settings, pins, all seven frozen refs/rulesets/effective rules,
  Environment reviewer/admission/gate and other inventories matched.

PUT started **17:26:18.094 UTC**, returned HTTP 200 at **17:26:18.641 UTC**.
Independent readbacks completed **17:26:26.883 UTC**.
These are recording/observation times, not a claim of transactional observation
or the time the owner made the approval decision.

## Verified installed policy

Independent REST GET verified:

- Non-null required PR policy, approving count **0**.
- Dismiss stale reviews true.
- Code-owner and last-push approval false.
- Administrator enforcement true.
- Conversation resolution true.
- Every other main-protection field unchanged, including no force push/deletion
  and unchanged status-check/push-restriction/signature/history settings.

Independent native GraphQL verified unique main rule
`BPR_kwDOT7mVms4E6Id6` with complete rule pagination and unchanged rule inventory:

```json
{
  "pattern": "main",
  "isAdminEnforced": true,
  "requiresApprovingReviews": true,
  "requiredApprovingReviewCount": 0,
  "dismissesStaleReviews": true,
  "requiresCodeOwnerReviews": false,
  "requireLastPushApproval": false,
  "requiresConversationResolution": true,
  "restrictsPushes": false,
  "restrictsReviewDismissals": false,
  "bypassPullRequestAllowances": {
    "totalCount": 0,
    "pageInfo": {"hasNextPage": false}
  }
}
```

Zero native actors, not an omitted REST field, supplies the PR-bypass proof.
The installed count-zero policy requires the ordinary PR path without requiring
an approving review during this narrowly authorized exception window; enforced
admins do not provide an admin bypass. Manual scope remains exact PR #26,
not a technical claim that this policy can admit only that PR.

This is an actual GitHub acceptance/readback result for the corrected window,
unlike the earlier offline compatibility check. It is not acceptance of the
unapplied count-two closure body, authenticated UI proof, G5 authorization or
qualification of A/a future merge commit.

## Preserved invariants — all 22 post-action checks passed

- Repository merge commits true; squash false, rebase false, auto-merge false;
  unrelated settings and ownership unchanged. Successful earlier PATCH was
  **not replayed**.
- Main ref/effective rules, exact A/PR state/tree/parents unchanged.
- Candidate C7 pin and every older/C7 producer pin unchanged (C7 producer B).
- Frozen C/C2/C3/C4/C5/C6/C7 refs, detailed active/no-bypass rulesets and
  effective protections unchanged, including integration-15368 strict identity
  status requirements for C2–C7 and their initial-create exemptions. Original C
  received no new status requirement.
- Environment `ledgerly-canonical` ID 20664477675 unchanged: required owner
  reviewer, `prevent_self_review=false`, custom branch admissions exactly main
  and `tr01/implementation-identity-successor-c7`, no tags/wildcards.
- Environment `can_admins_bypass=true` remains a retained capability; no use
  authorized or performed. It is distinct from main's enforced-admin policy.
- Collaborators, repository variables and repository/Environment secret-name
  inventories unchanged; no secret values read.

## Approved future closure — NOT triggered or applied

The owner approved the corrected closure plan restoring **two approvals** for
its recorded future exception-ending conditions (completion, failure,
revocation, expiry or unapproved drift) with fresh preservation checks.
Setup success alone does not close the window.

At an authorized closure time, recheck exact body hash and current controls;
stop for newly added checks/actors/drift rather than overwrite additions with
stale nulls. Use the exact corrected closure body in a separate approved PUT.
Independently verify REST/native count two, every strengthened field,
administrator/conversation enforcement and zero bypass actors, preserving
merge-only, frozen controls, pins and Environment gate. Retain response and
readbacks. Error means hold/report, not automatic retry or weaker rollback.
Future owner-authored PRs cannot satisfy two eligible reviews with only the
owner collaborator; that accepted consequence remains part of the plan.

## Pending authenticated UI handoff to Codex

Codex must perform a **read-only, authenticated browser inspection** of
GitHub main protection and repository merge settings. Confirm mandatory PR
policy/count zero, stale review dismissal, administrator enforcement,
conversation resolution, no bypass actors and merge-only settings against
these receipts. Retain timestamped UI evidence. Report discrepancies before
any later gate. Do not label REST/GraphQL as UI inspection.

G4 is **API_APPLIED_AND_VERIFIED_UI_PENDING**, not fully verified/completed.
G5–G7 remain pending. No PR readiness, merge, workflow dispatch, Environment
release, runtime change, migration, production/Helium access, deployment, push
or Phase A occurred or is authorized. Exact-C7 historical development
qualification remains exact-C7 only.

## Evidence

Thin durable receipts accompany this report under
`ledgerly-tr01-c7-g4-corrected-application/`; full independent captures and the
single-call script are in the delivered application evidence ZIP. Response
headers are reduced to HTTP status, content type, date, API version and GitHub
request ID; body bytes are retained. No credential values are included.

Local branch records this decision/execution separately from A, C7 and all
frozen candidate branches. No GitHub push was performed.


---

# G4 — UI verification addendum

Source: `docs/governance/ledgerly-tr01-c7-g4-codex-ui-verification-addendum.md`

# G4 Codex AI UI-verification addendum — 2026-10-13

**Current reconciled status: G4 VERIFIED COMPLETE. G5–G7 remain PENDING.**

This dated addendum records the owner's report of Codex's actual authenticated
Chrome observation and independent control checks. It completes the UI handoff
left pending in the earlier Replit application record. It is **Codex AI browser
verification**, not Replit browser inspection or independent-human review.
No new live requests or control changes were made to produce this addendum.

## Preserved historical record

Local record commit:
`fcad7a07e115aa556f1d2037c759b8580f9124ff`.

Its [application report](drafts/ledgerly-tr01-c7-g4-corrected-application-report.md),
UI-pending status, approval, single HTTP-200 PUT and original receipts remain
unchanged. The commit is retained in local history. Its earlier UI-pending
statement was accurate at execution time; this addendum supplies the subsequent
handoff rather than rewriting it.

The existing API evidence records the single exact corrected window body
SHA-256 `d96d829a3df69c397b032fe1a1eb308d9f98fada72efcb8495a9e17c18b354e6`,
approved review ZIP SHA-256
`090b51fd4ad655001db0fa4b725610c1af2b9b326431b446d67e7999c71a79d7`,
20 passing preflight checks and 22 passing post-action checks.
Original approval and HTTP 422 evidence remain intact.

## Codex's reported actual browser observation

- Observed at **2026-10-13T17:30:39.765Z**.
- Authenticated Chrome, read-only.
- URL: <https://github.com/Future00111/ledgerpoint/settings/branch_protection_rules/82347898>.
- Branch pattern: **main**.
- **Checked:** Require a pull request; stale-review dismissal; conversation
  resolution; administrator enforcement.
- **Unchecked:** Require approvals; code-owner approvals; last-push approvals;
  status checks; signatures; linear history; deployments; lock; force pushes;
  deletions.
- **No checkbox changed. Save was not clicked.**

The unchecked approval requirement is consistent with the installed count-zero
window policy; it does not negate the checked mandatory-PR requirement.
These UI observations are attributed to Codex as relayed directly by the owner.
No screenshot or browser trace was attached to this recording request; this
addendum does not invent one or claim Replit independently inspected Chrome.

## Codex's reported independent verification

The owner also reports that Codex independently verified:

- REST policy and complete native GraphQL pagination with zero bypass actors.
- Exact A `ead19106aaad76d604e8595337b5ab2fddda68d0`.
- Exact B/main `0da401737f35d68b9404982baad7405fe997636a`.
- Exact C7 `787d76decfa345e3c1104231e08d5ab00bc90259`.
- PR #26 draft and unmerged.
- Merge-only repository settings and all retained controls.

This reconciles the earlier verified REST/native result with the actual UI
handoff. Native actor-count proof remains distinct from UI inspection; an
omitted REST bypass field alone is still insufficient.
The timestamp above belongs to Codex's UI observation; no distinct timestamps
are asserted for its other checks.

## Reconciled gates and remaining limits

G4's corrected configuration and verification stage is recorded as **VERIFIED
COMPLETE**, using the preserved Replit API receipts plus the owner's report of
Codex's actual authenticated UI and independent checks.

This is not a merge, activation, run or release approval. G5–G7 remain pending.
The ordinary PR requirement, enforced administrators, stale dismissal,
conversation resolution and zero native bypass actors remain the recorded
window controls. Exact pins, frozen protections, Environment gate and
merge-only settings remain preserved per the existing receipts and Codex report.
The Environment's existing administrator-bypass capability is not claimed
disabled; its use remains forbidden.

The corrected future closure plan restoring **two approvals** remains approved
under its recorded exception-ending conditions, with fresh preservation checks.
Completing G4 verification does not itself trigger closure. Closure is not
performed here. Its body SHA-256 remains
`fc4d8f277df504e9fff50a2e9bb30a52d4fe22fd25cff3013d78a4bfb9724e7c`.

This request authorizes documentation/status recording only: **no further live
requests, closure, push, PR readiness change, merge, dispatch, Environment
release, deployment, migration, production/Helium access or Phase A**.
Existing development qualification remains bound to exact C7; it does not
qualify A or a future merge identity.


---

# G5 — ordinary merge

Source: `docs/governance/drafts/ledgerly-tr01-c7-g5-ordinary-merge-report.md`

# G5 exact PR26 ordinary merge — 2026-10-14

**G5 COMPLETE. G6/G7 remain PENDING. Development-only scope.**

Owner approval was [relayed through Codex](../ledgerly-tr01-c7-g5-owner-merge-approval.md).
This is Replit AI execution/verification under G1, not independent-human review.
No activated qualification or deployment is claimed.

## Exact result

- PR: <https://github.com/Future00111/ledgerpoint/pull/26>, closed/merged, not draft.
- **G / current remote main:** `706dc6a31f85733ba0c251f40b2c09f5a9312269`.
- Commit: <https://github.com/Future00111/ledgerpoint/commit/706dc6a31f85733ba0c251f40b2c09f5a9312269>.
- Ordered parents:
  1. B `0da401737f35d68b9404982baad7405fe997636a`.
  2. A `ead19106aaad76d604e8595337b5ab2fddda68d0`.
- G tree = A tree: `bf7c91fac7fe09d8458a327dd79464ea1a3973ad`.
- C7 remains `787d76decfa345e3c1104231e08d5ab00bc90259`.
- B, A and C7 are ancestors of G. A's ordered parents remain [B,C7].
- Authenticated actor and merge actor: `Future00111`, GitHub user ID 318002590.
- GitHub merged timestamp: **2026-10-14T15:13:26Z**.
- Exact G/B union comparison: **ten permitted paths**, every other B entry,
  blob/mode and absence preserved; **518 outside-inventory union entries**.
- Complete remote recursive G tree was read, not truncated, and equals the
  local immutable A tree entry-for-entry.

GitHub's merged PR record retains `base.sha=B`; remote main independently
reads G. These represent different facts. Neither a PR's historical base field
nor a pre-merge synthetic `merge_commit_sha` is substituted for actual G.

## Action-time evidence and one normal attempt

1. Original planning HEAD/history preserved; separate local branch
   `records-local/tr01-c7-g5-authorized-merge` created from
   `1da03b94b37f88f55f0f96ba0afc1b4013879e96`.
2. Relayed approval recorded before live action in commit
   `04ec3a73f3ace83e05ec5a2af1a88c515c439ea0`.
3. Fresh preflight **2026-10-14T15:12:11.586272–15:12:23.580370 UTC**:
   all **40 checks passed**. G1–G4/proposal bytes, original workbook, actor,
   A/B/tree/parents/ancestry/inventory, reviews/checks and controls verified.
4. One normal `gh pr ready 26 --repo Future00111/ledgerpoint` succeeded;
   response and readback retained. No other PR readiness changed.
5. Repeated full ready-state preflight passed, including unchanged review/
   check evidence and complete native policy. Authenticated actor, exact A,
   main B, open/ready/clean/mergeable state were read immediately before merge.
6. Exactly one normal command succeeded, exit 0, empty stdout/stderr:

   ```text
   gh pr merge 26 --repo Future00111/ledgerpoint --merge \
     --match-head-commit ead19106aaad76d604e8595337b5ab2fddda68d0
   ```

   No admin, force, squash/rebase, auto merge, branch deletion, direct push,
   head/base update or policy relaxation. Exclusive attempt markers were
   persisted before each action. No action retry.
7. Raw PR readback supplied actual G. Complete postmerge control receipts
   and supplemental native/tree/review readback establish the result.
   Final readback completed **2026-10-14T15:14:58.453806 UTC**.

The head guard is not an atomic base lease. No unrelated main write was made
by this agent; external writers cannot be locked by the CLI command. Actual
ordered [B,A] parents and exact A tree demonstrate the expected resulting
topology, without inventing an atomic-base guarantee.

## Preserved checker failure and read-only reconciliation

At **2026-10-14T15:13:38.570299 UTC**, the first postmerge checker stopped:
it incorrectly required merged PR `base.sha=G`. The provider retained reviewed
B in the PR record while main read G. The original script, log, stop receipt
and captured controls remain unchanged.

Offline inspection of those captured receipts proved this was a local
readback-assumption defect, not source/control drift. No GitHub correction or
action retry followed. A separate read-only reconciliation reused the captured
control observations, completed the missing native/review/tree readbacks and
read final PR/main. All **42 reconciliation checks passed**. Historical stopped
evidence is not replaced or silently erased.

Legacy preparation-check keys in copied receipts retain their historical names
(`exactDraftUnmergedPR`, `mainExactB`, `mergeable`), but the retained reconciliation
script explicitly tests merged/not-draft PR, main=G and merged state for those
postmerge predicates. The scripts and raw records make this adaptation auditable.

## Retained controls and assurance limits

G4 mandatory PR/count-zero window, enforced administrators, stale dismissal,
conversation resolution and complete native **zero bypass actors** are preserved.
Merge-only settings remain merge=true, squash/rebase/auto=false.
Frozen C through C7 refs, seven active no-bypass protections/effective rules,
candidate/producer pins, exact main+C7 Environment admission, owner reviewer,
custom policy and all other recorded Environment settings are unchanged.
Existing administrator-bypass capability is not claimed disabled; it was not used.
No browser/UI inspection was attempted or claimed this turn; G4's historical
actual Codex browser addendum remains attributed to Codex.

Reviews, requested reviewers, threads, head checks and head statuses remain
zero. Absence of checks is **not CI success** or independent-human approval.
G3's six image-dependent skips remain skips. No tests were rerun or reclassified.
Existing C7 qualification applies to exact C7, **not G**.
No workflow run exists on G in the retained readback; no dispatch was performed.

## Evidence and next gates

Tracked summaries:
`docs/governance/drafts/ledgerly-tr01-c7-g5-ordinary-merge/`.

Full original approval relay, raw GET/native pages, command responses, consumed
attempt markers, first checker failure, reconciliation receipts/scripts and logs:
`generated-artifacts/ledgerly-c7-g5-authorized-merge/`.
The final ZIP manifest records all hashes and local approval/outcome commits.
Original approvals, failure evidence, workbook/source and runtime/history remain
unchanged; this is a local records commit, not runtime synchronization to main.

**Next gate: separate G6 exact-G/C7 preflight and owner run/release authorization.**
No such authorization is inferred from G5. G7 activated-result acceptance and
the conditionally approved two-approval closure remain separate. Closure was
not triggered or attempted here.

No push, dispatch, Environment release, closure/control change, runtime/schema/
workflow edit, migration, production/Helium access, deployment, publishing or
Phase A occurred. No suggested follow-up implementation was started.


---

# G6 — authorised dispatch

Source: `docs/governance/drafts/ledgerly-tr01-c7-g6-dispatch-report.md`

# G6 single dispatch — stopped at human Environment review

## Outcome — 2026-10-14

**One approved dispatch consumed. Human Environment review pending.
G7 pending. No qualification result exists for G at this handoff.**

Actual run: [38621069723](https://github.com/Future00111/ledgerpoint/actions/runs/38621069723),
attempt **1**, event `workflow_dispatch`, source branch `main`, exact G
`706dc6a31f85733ba0c251f40b2c09f5a9312269`.
Actual job: [116048423733](https://github.com/Future00111/ledgerpoint/actions/runs/38621069723/job/116048423733),
`Disposable canonical PostgreSQL qualification`, workflow job key
`canonical-postgresql`. Run and job are **waiting**, conclusion null;
job steps are empty at the retained readback.

Pending Environment is exact `ledgerly-canonical`, ID `20664477675`,
required reviewer **Future00111**, user ID `318002590`.
The API says the authenticated user can approve; this is a capability,
**not agent authorization**, and was not exercised.
The owner must personally open the actual run, inspect G/C7/attempt/job,
then use normal **Review deployments → ledgerly-canonical → Approve and deploy**.
That GitHub label releases this development job, not a production deployment.
No API approval, UI click, bypass or automated release was performed.

## Approval and fresh preflight

See [the recorded owner approval](../ledgerly-tr01-c7-g6-owner-dispatch-approval.md).
Approval record commit: `ea73d7a04fac8738aa193965897b0391ea7a7c68`.
Owner quote **“i approve G6”** is attributed to the relay through Codex,
not a signature or independent-human review.
The original prepared package and historical approval/failure/fixture
records remain unchanged.

Fresh full read-only preflight:
**2026-10-14T19:07:06.578393Z–19:07:21.276811Z**, **49/49 passed**.
Exact G/A tree `bf7c91fac7fe09d8458a327dd79464ea1a3973ad`,
ordered G parents [B `0da401737f35d68b9404982baad7405fe997636a`,
A `ead19106aaad76d604e8595337b5ab2fddda68d0`], C7 ancestry,
ten permitted paths and all outside-B blobs/modes/absence reconfirmed.
Native policy pagination complete, zero bypass actors; G4 window,
merge-only settings, frozen refs/protections, pins, owner Environment gate
and exact main+C7 admission unchanged. Repository/Environment secret-name
counts zero; no secret values, production or Helium accessed.
No prior G workflow run or active conflicting canonical run was found.

Frozen C7 remains `787d76decfa345e3c1104231e08d5ab00bc90259`;
historical producer pin remains B. Workflow ID `343787048`, exact G path
`.github/workflows/ledgerly-canonical-postgresql.yml`, SHA-256
`ad06da35f4269fbbf46e1fd4ccabf6082d309963e39b577e17ac948c546afc20`.
This establishes intended C7 execution through the exact workflow/pin;
the waiting job has not checked out or qualified it yet.

## Exact action and readback

An exclusive, fsynced consumed marker was persisted **before** the
immediate main=G read and the sole POST. `action-decision.json` binds
approval, actual actor, source/control/native-policy/run preflight receipts
and their SHA-256 hashes. No retry code or alternate request was used.

POST `repos/Future00111/ledgerpoint/actions/workflows/343787048/dispatches`,
API version `2022-11-28`, exact body `{"ref":"main"}` plus one LF,
15 bytes, SHA-256
`455eddddcfdd09a482991d88045379bf46c72f839eb6640decc52657470b3f74`.

Request window:
**2026-10-14T19:07:56.806135Z–19:07:58.611191Z**.
Response **HTTP 204**, one request, exit 0.
GitHub request ID `D3EA:3F8732:3078308:486D4C7:6ACFD30D`.
Unique run created **2026-10-14T19:07:58Z**, within that window;
workflow ID/path, G/main, event, attempt, actor and triggering actor
Future00111/318002590 all match. Main readback remains exact G.
Immediate source checks are **not an atomic main-ref lease**.

## Retained records and limits

Tracked receipts: `docs/governance/drafts/ledgerly-tr01-c7-g6-dispatch/`.
Full raw controls, policy pages, source/tree, run inventory, scripts and
logs: `generated-artifacts/ledgerly-c7-g6-authorized-dispatch/`.
The readback verification file contains receipt SHA-256 hashes.
Separate local branch: `records-local/tr01-c7-g6-authorized-dispatch`.
No push. No other live write, source/control/closure change, merge, rerun,
cancellation, migration, production/Helium contact, deployment/publishing
or Phase A. No automatic polling through the human gate.

Historical C7 evidence and local source fixtures do not qualify G.
G3's six skips remain skips. After a personally authorized human release,
actual new schema2 artifact/source/run/image/accounting/concurrency/
18-negative-control/five-cleanup evidence must still be verified;
G7 result acceptance and closure remain separate. No follow-up started.


---

# G7 — verification and acceptance proposal

Source: `docs/governance/drafts/ledgerly-tr01-c7-g7-acceptance-proposal.md`

# G7 acceptance proposal — run 38621069723 / attempt 1

**G7: ACCEPTED on the user's explicit instruction. This qualification stage is complete.**

See [recorded acceptance](ledgerly-tr01-c7-g7-acceptance/owner-acceptance.md) and the structured decision in owner-acceptance.json. The review below is preserved as the supporting proposal.

Prepared on 2026-10-20 from the original GitHub artifact, attempt-specific logs and API metadata. This is a review proposal, not an owner attestation or governance closure. No new qualification run, production operation or Phase A authorization is represented.

## Decision scope and identity

| Item | Verified value |
| --- | --- |
| Repository | Future00111/ledgerpoint |
| Run | [38621069723, attempt 1](https://github.com/Future00111/ledgerpoint/actions/runs/38621069723) |
| Job | [116048423733](https://github.com/Future00111/ledgerpoint/actions/runs/38621069723/job/116048423733), canonical-postgresql |
| Event / source ref | workflow_dispatch / refs/heads/main, protected |
| Identity mode | activated |
| Workflow source G | `706dc6a31f85733ba0c251f40b2c09f5a9312269` |
| Implementation C7 | `787d76decfa345e3c1104231e08d5ab00bc90259` |
| Actor / triggering actor / Environment reviewer | Future00111 |
| Run created | 2026-10-14T19:07:58Z |
| Job execution | 2026-10-20T18:20:59Z to 18:22:00Z (61 seconds) |
| GitHub outcome | success; all nine job steps successful |
| Run UUID | `283124e1-47d4-4754-ae97-e0f59c2f579e` |
| Disposable database | `ledgerly_canonical_test_283124e147d44754ae97e0f59c2f579e` |
| Nonce SHA-256 | `27c8a1fe756842bc5e1213ca4519a7e587465eae3a9396efbee79d73dc0954a0` |

The Environment approval record is retained in reviews.json. The API response does not supply a precise approval timestamp; the job execution timestamps above are not represented as approval timestamps.

## Verification outcome

Strict AJV 2020 validation with AJV 8.20.0 and the frozen C7 coordinator's branded, source-bound acceptance validator passed. The validator recomputed all ten source digests from fresh detached G and C7 checkouts and verified clean tracked trees plus C7 ancestry in G. The execution-tree digest covers 564 files. Uploaded schema bytes equal the schema at C7.

The offline verification receipt records 19 passing groups. Additional archive/marker verification passed: unique safe ZIP member names, no symlinks or duplicate JSON keys, valid CRCs, exactly two expected artifact members, and completion-marker agreement. These are evidence-review checks, not extra qualification tests.

The previous preparation host checkout had moved to another commit. It was excluded from source attribution; fresh exact detached checkouts were used. Its existing AJV installation was reused, with version 8.20.0 checked. No application dependencies were installed or database/Docker commands run during this review.

## Accounting tests — 6/6 PASS

| # | Test in original qualification log | Result |
| --- | --- | --- |
| 1 | canonical integration suite is bound to an empty API-role disposable database | PASS |
| 2 | canonical posting persists a balanced immutable journal, audit, and retry-safe effect | PASS |
| 3 | canonical posting fails closed for stale sources, closed periods, invalid accounts, and company mismatch | PASS |
| 4 | canonical posting is atomic under audit failure, concurrent retries, and additive reversal | PASS |
| 5 | SC-01 enforces company-scoped relation identity, uniqueness, and atomic rollback | PASS |
| 6 | owner journal locks serialize transactions without API mutation privileges | PASS |

Original test summary: tests 6; pass 6; fail 0; cancelled 0; skipped 0; todo 0; duration 625.940792 ms. These six integration results are distinct from historical offline image-dependent skips, which remain historical skips.

## Concurrency checks — PASS

Concurrent retry arrivals use backend PIDs **179 and 180**, with distinct transaction IDs **891 and 892**. Arrival timestamps are **1792520516844** and **1792520516850**; barrier release is **1792520516850**. Both transactions arrived before release, and overlapProven is true. The log marker exactly matches the artifact.

The independent owner-mediated journal-lock test passed using backend PIDs **186 and 187**. Function owner is ledgerly_canonical_owner; callerHasUpdate is false. Scoped lookup rejection, direct mutation denial, temporary-shadow rejection and transactional row-lock serialization are all true. The original test log and evidence agree.

## Negative controls — 18/18 PASS

| # | Control | Recorded result | Reviewed rejection meaning |
| --- | --- | --- | --- |
| 1 | `missingRunBinding` | PASS | Missing UUID binding rejected with required-run-id diagnostic. |
| 2 | `forgedRunDatabaseMismatch` | PASS | Forged UUID/database binding rejected by private run-binding verification. |
| 3 | `malformedUri` | PASS | Malformed target rejected as Invalid URL. |
| 4 | `targetChangingQuery` | PASS | Target-changing or duplicate query parameter rejected. |
| 5 | `wrongHost` | PASS | Non-exact host rejected. |
| 6 | `wrongPort` | PASS | Non-exact port rejected. |
| 7 | `wrongDatabase` | PASS | Non-exact database rejected. |
| 8 | `wrongRole` | PASS | Non-exact role rejected. |
| 9 | `parentDatabaseUrl` | PASS | Inherited parent DATABASE_URL rejected. |
| 10 | `replitMarker` | PASS | Inherited Replit marker rejected. |
| 11 | `inheritedPgOverride` | PASS | Inherited PostgreSQL target override rejected. |
| 12 | `unpinnedImage` | PASS | Unpinned image rejected by image guard. |
| 13 | `untrustedEvent` | PASS | Untrusted workflow event rejected. |
| 14 | `unauthorizedWorkflow` | PASS | Unauthorized workflow identity rejected. |
| 15 | `cleanupBindingMismatch` | PASS | Mismatched cleanup UUID fails private binding count check. |
| 16 | `evidenceCredentialPattern` | PASS | Credential-shaped evidence rejected by sanitizer. |
| 17 | `roleEscalation` | PASS | API role escalation and SET ROLE postgres denied in runtime marker. |
| 18 | `triggerDisable` | PASS | Trigger disable and canonical delete denied in runtime marker. |

The first eleven runner probes require specific rejection diagnostics in the reviewed coordinator. Image, event, workflow and credential-pattern probes require rejection of isolated mutations. Cleanup mismatch uses the private binding check; privilege controls are supported by runtime markers. Quiet per-control stderr is not retained in the uploaded artifact/log, so individual rejection reasons are established by source review plus the hash-bound success flags, not by 18 separately preserved stderr transcripts.

## Cleanup checks — 5/5 PASS

| Check | Recorded result | Evidence meaning |
| --- | --- | --- |
| `logicalDrop` | PASS | Run-bound logical DROP DATABASE completed after exact UUID/database/nonce/creator/runtime verification. |
| `databaseAbsent` | PASS | Post-drop database-catalog absence check succeeded. |
| `containerRemoved` | PASS | Disposable PostgreSQL container removal and inspect-absence check succeeded. |
| `networkRemoved` | PASS | Disposable network removal and inspect-absence check succeeded. |
| `credentialMaterialRemoved` | PASS | Credential directory recursive removal completed successfully; no separate stat receipt retained. |

The frozen cleanup path verifies the exact run UUID, database, nonce, creator postgres and runtime ledgerly_api before logical destruction. The five true flags are in the validated final evidence, written after cleanup. Quiet SQL/Docker cleanup output is not separately retained. This review verifies the recorded checks and their source implementation; it does not claim to re-inspect resources after the disposable runner ended.

## Bootstrap, privileges and isolation

The API role is LOGIN with no superuser, inheritance, CREATE DATABASE, CREATE ROLE, replication or BYPASSRLS; the canonical owner is NOLOGIN with the same restrictions. No API role memberships are present. All five canonical tables are owner-owned. API ACLs grant SELECT/INSERT on append-only tables, with UPDATE additionally present only on posting effects. The private schema ACL remains postgres-only.

The evidence contains 17 constraints, four posting-effect indexes, seven validated relation foreign keys, five ENABLE ALWAYS triggers, an empty initial canonical baseline and private run binding. Journal-lock function ownership, SECURITY DEFINER, volatile designation, fixed pg_catalog/pg_temp search path, API-only execute permission and absence of API update/delete/truncate privileges were checked. Six guard/verifier functions and their fixed search paths are retained in the original evidence.

Isolation flags confirm no parent DATABASE_URL or Replit variables, no published ports, an internal network, no test-container Docker socket and no external route. Helium and production contact flags are false; the credential scan passed. Reviewed Dockerfile runs as node; runner options restrict capabilities, privileges and filesystem access.

PostgreSQL reports 16.15. Pinned image identities are retained in the evidence. Node 24.13.0 and pnpm 10.26.1 are recorded; the Docker build includes a successful non-network toolchain check as the node user. Node runtime version is a coordinator-recorded field rather than a separate runtime-version transcript.

### Disclosed bootstrap recovery

The initial Drizzle push encountered the specifically handled SQLSTATE 42830 ordering error involving accounting_posting_effects. The reviewed C7 coordinator added its narrow prerequisite index and completed a second successful push. Evidence records recoveredOrdering=true and pushes=2. This was an approved bootstrap recovery within attempt 1, not a failed accounting test or GitHub rerun.

## Artifact integrity and retention

| Object | SHA-256 |
| --- | --- |
| Original artifact ZIP | `41ccf0941649ffd35e9e1e5e5d588e46f3a2b3579af943fffe2f720e7fdd048f` |
| Original attempt log ZIP | `d72c9e314446911beb8005f62226693a320e514d5a5aee4f4f36473eb32aa0de` |
| Evidence JSON | `1ed8e4b18f0a3809230ba0715eef9f10640e36ba1101f4a2f8dce57998a73c1a` |
| Schema JSON | `6ba3d5f595f81e81db238b843c16b667e775384952855482ce9a978775d6ca0f` |

Artifact **12288971026**, named **ledgerly-ti-03-38621069723-1**, is 5,290 bytes. Its ZIP digest matches GitHub artifact metadata and the upload log. The artifact contains only the evidence JSON and frozen schema. GitHub expiry is 2026-11-19T18:21:58Z. Original ZIPs, extracted members, logs, API metadata, full member inventories, source digest receipt and verification script/results are retained in the sibling `ledgerly-tr01-c7-g7-acceptance/` directory.

| Source component | Recomputed SHA-256 |
| --- | --- |
| sourceTree | `fcd81d162cbfc406853bdd13c853cd49f81fd814622a7f90116724e668eb82d1` |
| applicationSchema | `67c2c27243abcdd35c1e6c5e3fa78fc7f537dce914677a8ef799ba1eb116f564` |
| drizzleConfig | `57862221556f24a1accd28b283876930c403ad7c86b79d87cfb5c9c200ba6258` |
| securityOverlay | `779d76aa3ab065d5bb1f5a08c9ea807cf4bc3166d0fdc1b59c21c81140404081` |
| runControlSql | `cf7c294738f2400e5ce5ab7abcb1cc111bd8100a62386d075306ced6395bf00b` |
| coordinator | `224275124927ffabc03a0720acb67bd4b2d3e99db8183d1c2eca4283e7440427` |
| testSources | `2573b8b7be50acaadc68be89c6de53dbdb9279132455dac99fa02206bca916ac` |
| lockfile | `3b8329fff64eab80ec5dfe8d875f80502789520faea4680d2fd0e7f0b4703f1b` |
| workflow | `ad06da35f4269fbbf46e1fd4ccabf6082d309963e39b577e17ac948c546afc20` |
| orchestrator | `3699a2ad28b5d2e3e652529c2d26bec8b7c84b7ff658fa8a08b4ae6f456ef54b` |

Fresh read-only main/C7 and Environment/variable observations are retained. The configured candidate pin remains C7; the approved-workflow pin retains its G6 meaning and was not changed to G. The approved Environment configuration includes can_admins_bypass=true; this is disclosed retained configuration, not a bypass used by this run. No controls were altered during verification.

## Original proposed acceptance wording — retained for context

> I accept the G7 evidence for GitHub run 38621069723, attempt 1, workflow source G 706dc6a31f85733ba0c251f40b2c09f5a9312269 and implementation C7 787d76decfa345e3c1104231e08d5ab00bc90259, limited to the activated disposable-CI qualification. I have reviewed the six accounting passes with no skips, concurrent transaction and journal-lock evidence, all 18 negative controls, all five cleanup checks, source bindings and artifact digests, including the documented bootstrap recovery and evidence granularity limits.

Acceptance authority: **User's explicit instruction in ChatGPT; recorded by Codex on their behalf**  
Acceptance recorded at: **2026-10-20T20:02:25.181504+01:00 (Europe/London)**  
Acceptance record/reference: **ledgerly-tr01-c7-g7-acceptance/owner-acceptance.json**  
G7 qualification stage: **COMPLETE**

This proposal does not itself authorize production, Phase A, another dispatch, a rerun, a push or changes to frozen controls. The user's subsequent acceptance is recorded in the linked decision.

## Review sources

- `ledgerly-tr01-c7-g6-evidence-cleanup-checklist.md`
- `ledgerly-tr01-c7-g6-review-attestation-package.md`
- `ledgerly-tr01-c7-g6-dispatch-report.md`
- Original run, artifact and attempt logs retained alongside this proposal.
- Frozen C7 coordinator and orchestrator, G workflow, and exact C7 execution sources.


---

# G7 — recorded acceptance

Source: `docs/governance/drafts/ledgerly-tr01-c7-g7-acceptance/owner-acceptance.md`

# G7 acceptance — recorded

**G7: ACCEPTED. This accounting qualification stage is complete.**

Recorded on the user's explicit instruction in ChatGPT: **“can you sign of G7”**.
Codex recorded this decision on the user's behalf after presenting the verification
results, acceptance proposal and its stated limitations.

Recorded at: **2026-10-20T20:02:25.181504+01:00 (Europe/London)**.

| Item | Accepted scope |
| --- | --- |
| GitHub run | [38621069723, attempt 1](https://github.com/Future00111/ledgerpoint/actions/runs/38621069723) |
| Workflow source G | `706dc6a31f85733ba0c251f40b2c09f5a9312269` |
| Implementation C7 | `787d76decfa345e3c1104231e08d5ab00bc90259` |
| Accounting tests | 6 passed; 0 failed; 0 skipped |
| Concurrent retries and journal locks | Both passed |
| Negative controls | 18/18 passed |
| Cleanup checks | 5/5 recorded successful |
| Source and artifact integrity | Strict schema, all ten source digests and archive integrity verified |

The acceptance covers the activated disposable-CI qualification for this exact run.
The documented bootstrap ordering recovery and evidence granularity limits remain
part of the accepted review record. This decision does not grant production or Phase A authorization.

The original verification evidence is preserved. Its earlier PENDING status describes
the state at verification time; this acceptance record supersedes that status.

The complete decision is in `owner-acceptance.json`. The original unsigned proposal
is preserved as `proposal-before-owner-acceptance.md`. The current proposal links here.

