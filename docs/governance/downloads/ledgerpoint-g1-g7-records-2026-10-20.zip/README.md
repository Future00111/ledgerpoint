# LedgerPoint G1–G7 records
Packaged 2026-10-20 at the owner's request.

Start with G1-G7-READABLE-RECORDS.md for the main documents in gate order.
The docs/ folder contains the complete selected C7 gate records and related
approval/proposal/evidence files, preserved byte for byte.
MANIFEST.json records every original file's size and SHA-256.

Latest decision: G7 ACCEPTED for run 38621069723, attempt 1, G
706dc6a31f85733ba0c251f40b2c09f5a9312269 and C7
787d76decfa345e3c1104231e08d5ab00bc90259.
The owner-acceptance record is authoritative for that G7 decision.
Older PENDING text describes historical stages and is retained as evidence.
The G7 acceptance covers disposable-CI qualification, not production release.
Any separate control-restoration/closure conditions retain their own scope.

Included: approvals and preparation/application/merge/dispatch reports,
source-bound verification, six accounting results, concurrency/journal-lock
evidence, 18 negative controls, five cleanup attestations, original G7 artifact
and logs, integrity manifests, and the recorded owner acceptance.
This package is a snapshot; it does not rerun tests or change live controls.
